<?php
require_once 'koneksi.php';

// Cek login
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

// Ambil detail penjualan
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // Ambil data penjualan
    $stmt = $conn->prepare("SELECT s.*, c.nama as customer_nama, c.email, c.telepon, c.alamat 
                           FROM sales s 
                           LEFT JOIN customers c ON s.customer_id = c.id 
                           WHERE s.id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $sale = $result->fetch_assoc();
    
    if ($sale) {
        // Ambil detail item penjualan
        $stmt = $conn->prepare("SELECT si.*, p.nama as product_nama, p.sku 
                               FROM sale_items si 
                               JOIN products p ON si.product_id = p.id 
                               WHERE si.sale_id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $sale_items = $result->fetch_all(MYSQLI_ASSOC);
        
        // Tampilkan detail penjualan
        ?>
        <div class="sale-detail">
            <div class="sale-info">
                <h4>Informasi Penjualan</h4>
                <p><strong>Invoice:</strong> <?php echo $sale['invoice_no']; ?></p>
                <p><strong>Tanggal:</strong> <?php echo date('d/m/Y H:i', strtotime($sale['created_at'])); ?></p>
                <p><strong>Metode Pembayaran:</strong> <?php echo $sale['pembayaran_method']; ?></p>
                <p><strong>Total:</strong> Rp <?php echo number_format($sale['total_amount'], 0, ',', '.'); ?></p>
                <p><strong>Total Item:</strong> <?php echo $sale['total_items']; ?></p>
            </div>
            
            <?php if ($sale['customer_nama']): ?>
                <div class="customer-info">
                    <h4>Informasi Pelanggan</h4>
                    <p><strong>Nama:</strong> <?php echo $sale['customer_nama']; ?></p>
                    <p><strong>Email:</strong> <?php echo $sale['email']; ?></p>
                    <p><strong>Telepon:</strong> <?php echo $sale['telepon']; ?></p>
                    <p><strong>Alamat:</strong> <?php echo $sale['alamat']; ?></p>
                </div>
            <?php endif; ?>
            
            <div class="sale-items">
                <h4>Item Pembelian</h4>
                <table class="table">
                    <thead>
                        <tr>
                            <th>SKU</th>
                            <th>Produk</th>
                            <th>Harga</th>
                            <th>Qty</th>
                            <th>Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($sale_items as $item): ?>
                            <tr>
                                <td><?php echo $item['sku']; ?></td>
                                <td><?php echo $item['product_nama']; ?></td>
                                <td>Rp <?php echo number_format($item['price'], 0, ',', '.'); ?></td>
                                <td><?php echo $item['qty']; ?></td>
                                <td>Rp <?php echo number_format($item['subtotal'], 0, ',', '.'); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php
    } else {
        echo "<p>Data penjualan tidak ditemukan.</p>";
    }
} else {
    echo "<p>ID penjualan tidak valid.</p>";
}
?>