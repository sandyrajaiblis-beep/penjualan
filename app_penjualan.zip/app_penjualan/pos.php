<?php
require_once 'koneksi.php';

// Cek login
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

// Ambil data produk
$stmt = $conn->prepare("SELECT id, sku, nama, harga_jual, stok FROM products WHERE stok > 0 ORDER BY nama");
$stmt->execute();
$result = $stmt->get_result();
$products = $result->fetch_all(MYSQLI_ASSOC);

// Ambil data pelanggan
$stmt = $conn->prepare("SELECT id, nama, email FROM customers ORDER BY nama");
$stmt->execute();
$result = $stmt->get_result();
$customers = $result->fetch_all(MYSQLI_ASSOC);

// Generate invoice number
function generateInvoiceNumber($conn) {
    $date = date('Ymd');
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM sales WHERE DATE(created_at) = CURDATE()");
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $count = $row['count'] + 1;
    
    return 'INV-' . $date . '-' . str_pad($count, 4, '0', STR_PAD_LEFT);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kasir/POS</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Kasir/POS</h1>
            <div class="user-info">
                <span>Selamat datang, <?php echo $_SESSION['admin_name']; ?></span>
                <a href="logout.php" class="btn btn-logout">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </header>
        
        <div class="pos-container">
            <div class="pos-left">
                <div class="card">
                    <h2>Informasi Transaksi</h2>
                    
                    <div class="form-group">
                        <label for="invoice_no">Nomor Invoice</label>
                        <input type="text" id="invoice_no" value="<?php echo generateInvoiceNumber($conn); ?>" readonly>
                    </div>
                    
                    <div class="form-group">
                        <label for="customer_id">Pelanggan</label>
                        <select id="customer_id">
                            <option value="">-- Umum --</option>
                            <?php foreach ($customers as $customer): ?>
                                <option value="<?php echo $customer['id']; ?>"><?php echo $customer['nama']; ?> (<?php echo $customer['email']; ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="pembayaran_method">Metode Pembayaran</label>
                        <select id="pembayaran_method">
                            <option value="Tunai">Tunai</option>
                            <option value="Kartu Kredit">Kartu Kredit</option>
                            <option value="Transfer Bank">Transfer Bank</option>
                            <option value="E-Wallet">E-Wallet</option>
                        </select>
                    </div>
                </div>
                
                <div class="card">
                    <h2>Pilih Produk</h2>
                    
                    <div class="form-group">
                        <label for="product_search">Cari Produk</label>
                        <input type="text" id="product_search" placeholder="Ketik nama produk atau SKU...">
                        <div id="product_search_results" class="product-search-results"></div>
                    </div>
                    
                    <div class="form-group">
                        <label for="product_id">Produk</label>
                        <select id="product_id">
                            <option value="">-- Pilih Produk --</option>
                            <?php foreach ($products as $product): ?>
                                <option value="<?php echo $product['id']; ?>" data-harga="<?php echo $product['harga_jual']; ?>" data-stok="<?php echo $product['stok']; ?>">
                                    <?php echo $product['nama']; ?> (Rp <?php echo number_format($product['harga_jual'], 0, ',', '.'); ?>, Stok: <?php echo $product['stok']; ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="quantity">Jumlah</label>
                        <input type="number" id="quantity" value="1" min="1">
                    </div>
                    
                    <div class="form-group">
                        <button id="add_to_cart" class="btn btn-primary">
                            <i class="fas fa-plus"></i> Tambah ke Keranjang
                        </button>
                    </div>
                </div>
            </div>
            
            <div class="pos-right">
                <div class="card">
                    <h2>Keranjang Belanja</h2>
                    
                    <div id="cart_items" class="cart-items">
                        <p class="empty-cart">Keranjang belanja masih kosong</p>
                    </div>
                    
                    <div class="cart-summary">
                        <div class="cart-total">
                            <span>Total:</span>
                            <span id="cart_total">Rp 0</span>
                        </div>
                        
                        <div class="cart-actions">
                            <button id="clear_cart" class="btn btn-secondary">
                                <i class="fas fa-trash"></i> Kosongkan Keranjang
                            </button>
                            <button id="process_sale" class="btn btn-success">
                                <i class="fas fa-check"></i> Proses Penjualan
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="back-link">
            <a href="admin_dashboard.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Kembali ke Dashboard
            </a>
        </div>
        
        <footer>
            <p>&copy; <?php echo date('Y'); ?> Aplikasi Penjualan Barang</p>
        </footer>
    </div>
    
    <script src="assets/js/pos.js"></script>
</body>
</html>