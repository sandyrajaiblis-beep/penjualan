<?php
require_once 'koneksi.php';

// Cek login
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

// Hapus produk
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // Get product image path
    $stmt = $conn->prepare("SELECT gambar_path FROM products WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $product = $result->fetch_assoc();
    
    // Delete image file if exists
    if ($product['gambar_path'] && file_exists($product['gambar_path'])) {
        unlink($product['gambar_path']);
    }
    
    // Delete product from database
    $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Produk berhasil dihapus!";
    } else {
        $_SESSION['error'] = "Terjadi kesalahan: " . $conn->error;
    }
    
    header("Location: products.php");
    exit;
}

// Redirect jika tidak ada aksi yang valid
header("Location: products.php");
exit;
?>