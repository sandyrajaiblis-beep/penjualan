# Aplikasi Penjualan Barang

Aplikasi penjualan barang yang responsif untuk tampilan mobile menggunakan HTML, CSS, JavaScript (frontend) dan PHP + MySQL (backend).

## Fitur Utama

- Manajemen Produk (Admin)
  - Tambah / Edit / Hapus produk
  - Field produk: id, sku (unik), nama, kategori, deskripsi, harga_jual, harga_beli (opsional), stok, gambar (upload dan disimpan di server), created_at, updated_at
  - Validasi: SKU unik; gambar hanya JPG/PNG, max 2MB

- Transaksi Penjualan
  - Form transaksi: pilih produk (search/autocomplete), masukkan kuantitas, menambahkan beberapa item per transaksi
  - Saat transaksi disimpan, kurangi stok produk sesuai qty; jika stok tidak cukup tampilkan error
  - Simpan data transaksi ke tabel sales dan rincian ke sale_items
  - Tampilkan nomor invoice otomatis (unik)

- Pelanggan (opsional)
  - Bisa menyimpan data pelanggan: id, nama, email, telepon, alamat. Transaksi dapat dikaitkan ke pelanggan

- Login & Keamanan
  - Login admin (email & password). Password disimpan menggunakan password_hash() PHP
  - Proteksi halaman admin/dashboard dengan session

- Dashboard Admin
  - Melihat ringkasan: total penjualan hari ini, total pendapatan, jumlah produk habis/stok rendah
  - Daftar transaksi terakhir
  - Export data transaksi atau daftar produk ke CSV
  - Melihat dan mengunduh gambar produk

- Frontend (Catalog / Kasir sederhana)
  - Halaman katalog produk responsif (grid/list), dengan pencarian & filter kategori
  - Halaman kasir/pos untuk memasukkan transaksi cepat (mobile friendly)

## Persyaratan Sistem

- PHP 7.0 atau lebih tinggi
- MySQL 5.6 atau lebih tinggi
- Web server (Apache/Nginx)
- XAMPP (untuk pengembangan lokal)

## Instalasi

1. Ekstrak file aplikasi ke direktori web server Anda (misalnya `htdocs/aplikasi-penjualan`).

2. Buat database MySQL:
   - Buka phpMyAdmin di http://localhost/phpmyadmin
   - Buat database baru dengan nama `db_penjualan`
   - Impor file `install.sql` ke database tersebut

3. Konfigurasi koneksi database:
   - Buka file `koneksi.php`
   - Sesuaikan pengaturan database jika diperlukan (default sudah untuk XAMPP)

4. Buat direktori untuk upload gambar:
   - Buat direktori `assets/uploads/products`
   - Berikan permission write pada direktori tersebut (chmod 755 atau 777 jika diperlukan)

5. Akses aplikasi melalui browser:
   - Buka http://localhost/aplikasi-penjualan
   - Login dengan akun admin default:
     - Email: admin@example.com
     - Password: password

## Struktur Database

Aplikasi ini menggunakan struktur database sebagai berikut:

- `admins` - Tabel untuk data admin
- `categories` - Tabel untuk kategori produk
- `products` - Tabel untuk data produk
- `customers` - Tabel untuk data pelanggan (opsional)
- `sales` - Tabel untuk data penjualan
- `sale_items` - Tabel untuk detail item penjualan

## Penggunaan

### Admin

1. Login ke sistem menggunakan email dan password admin.
2. Pada dashboard, Anda dapat melihat ringkasan penjualan, produk stok menipis, dan transaksi terakhir.
3. Gunakan menu untuk:
   - Manajemen Produk: tambah, edit, atau hapus produk
   - Kasir/POS: membuat transaksi penjualan baru
   - Daftar Penjualan: melihat riwayat penjualan dan export ke CSV

### Kasir

1. Pilih menu Kasir/POS dari dashboard atau halaman utama.
2. Pilih pelanggan (opsional) dan metode pembayaran.
3. Cari produk menggunakan kolom pencarian atau pilih dari dropdown.
4. Masukkan jumlah produk yang dibeli.
5. Klik "Tambah ke Keranjang" untuk menambahkan produk ke keranjang belanja.
6. Ulangi langkah 3-5 untuk menambahkan produk lain.
7. Klik "Proses Penjualan" untuk menyimpan transaksi.

## Catatan

- Aplikasi ini dirancang untuk berjalan di lingkungan XAMPP di localhost.
- Untuk penggunaan di server produksi, pastikan untuk mengubah password default dan meningkatkan keamanan.
- File gambar produk disimpan di direktori `assets/uploads/products`.
- Pastikan direktori upload memiliki permission yang tepat agar dapat menyimpan file gambar.

## Lisensi

Aplikasi ini dibuat untuk tujuan pembelajaran dan dapat digunakan serta dimodifikasi sesuai kebutuhan.