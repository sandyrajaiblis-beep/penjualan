<?php
require_once 'koneksi.php';

// Cek login
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

// Ambil data kategori
$stmt = $conn->prepare("SELECT * FROM categories ORDER BY nama");
$stmt->execute();
$result = $stmt->get_result();
$categories = $result->fetch_all(MYSQLI_ASSOC);

// Edit produk
$product = null;
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $product = $result->fetch_assoc();
}

// Proses form
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $sku = $_POST['sku'];
    $nama = $_POST['nama'];
    $category_id = !empty($_POST['category_id']) ? $_POST['category_id'] : null;
    $deskripsi = $_POST['deskripsi'];
    $harga_jual = $_POST['harga_jual'];
    $harga_beli = !empty($_POST['harga_beli']) ? $_POST['harga_beli'] : null;
    $stok = $_POST['stok'];
    
    // Validasi SKU unik
   // Validasi SKU unik
if (isset($_POST['id'])) {
    // Saat edit produk, cek SKU kecuali untuk produk ini
    $stmt = $conn->prepare("SELECT id FROM products WHERE sku = ? AND id != ?");
    $stmt->bind_param("si", $sku, $_POST['id']);
} else {
    // Saat tambah produk baru, cek SKU saja
    $stmt = $conn->prepare("SELECT id FROM products WHERE sku = ?");
    $stmt->bind_param("s", $sku);
}
$stmt->execute();
$result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $error = "SKU sudah digunakan!";
    } else {
        // Handle upload gambar
        $gambar_path = $product['gambar_path'] ?? null;
        
        if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] == 0) {
            // Validasi tipe file
            $allowed_types = ['image/jpeg', 'image/png'];
            if (!in_array($_FILES['gambar']['type'], $allowed_types)) {
                $error = "Hanya file JPG/PNG yang diperbolehkan!";
            } elseif ($_FILES['gambar']['size'] > 2 * 1024 * 1024) { // 2MB
                $error = "Ukuran file maksimal 2MB!";
            } else {
                // Hapus gambar lama jika ada
                if ($gambar_path && file_exists($gambar_path)) {
                    unlink($gambar_path);
                }
                
                // Upload gambar baru
                $upload_dir = 'assets/uploads/products/';
                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0777, true);
                }
                
                $file_ext = pathinfo($_FILES['gambar']['name'], PATHINFO_EXTENSION);
                $file_name = uniqid() . '.' . $file_ext;
                $gambar_path = $upload_dir . $file_name;
                
                move_uploaded_file($_FILES['gambar']['tmp_name'], $gambar_path);
            }
        }
        
        if (!isset($error)) {
            if (isset($_POST['id'])) {
                // Update produk
                if ($category_id === null) {
                    // Gunakan query langsung tanpa parameter untuk NULL
                    $sql = "UPDATE products SET 
                            sku = ?, 
                            nama = ?, 
                            category_id = NULL, 
                            deskripsi = ?, 
                            harga_jual = ?, 
                            harga_beli = ?, 
                            stok = ?, 
                            gambar_path = ? 
                            WHERE id = ?";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("sssdisi", $sku, $nama, $deskripsi, $harga_jual, $harga_beli, $stok, $gambar_path, $_POST['id']);
                } else {
                    $sql = "UPDATE products SET 
                            sku = ?, 
                            nama = ?, 
                            category_id = ?, 
                            deskripsi = ?, 
                            harga_jual = ?, 
                            harga_beli = ?, 
                            stok = ?, 
                            gambar_path = ? 
                            WHERE id = ?";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("ssisddisi", $sku, $nama, $category_id, $deskripsi, $harga_jual, $harga_beli, $stok, $gambar_path, $_POST['id']);
                }
            } else {
                // Tambah produk
                if ($category_id === null) {
                    // Gunakan query langsung tanpa parameter untuk NULL
                    $sql = "INSERT INTO products (sku, nama, category_id, deskripsi, harga_jual, harga_beli, stok, gambar_path) 
                            VALUES (?, ?, NULL, ?, ?, ?, ?, ?)";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("sssddis", $sku, $nama, $deskripsi, $harga_jual, $harga_beli, $stok, $gambar_path);
                } else {
                    $sql = "INSERT INTO products (sku, nama, category_id, deskripsi, harga_jual, harga_beli, stok, gambar_path) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("ssisddis", $sku, $nama, $category_id, $deskripsi, $harga_jual, $harga_beli, $stok, $gambar_path);
                }
            }
            
            if ($stmt->execute()) {
                header("Location: products.php");
                exit;
            } else {
                $error = "Terjadi kesalahan: " . $conn->error;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $product ? 'Edit Produk' : 'Tambah Produk'; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="container">
        <header>
            <h1><?php echo $product ? 'Edit Produk' : 'Tambah Produk'; ?></h1>
            <div class="user-info">
                <span>Selamat datang, <?php echo $_SESSION['admin_name']; ?></span>
                <a href="logout.php" class="btn btn-logout">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </header>
        
        <div class="card">
            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <form method="POST" action="" enctype="multipart/form-data">
                <input type="hidden" name="id" value="<?php echo $product['id'] ?? ''; ?>">
                
                <div class="form-group">
                    <label for="sku">SKU</label>
                    <input type="text" id="sku" name="sku" value="<?php echo $product['sku'] ?? ''; ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="nama">Nama Produk</label>
                    <input type="text" id="nama" name="nama" value="<?php echo $product['nama'] ?? ''; ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="category_id">Kategori</label>
                    <select id="category_id" name="category_id">
                        <option value="">-- Pilih Kategori --</option>
                        <?php foreach ($categories as $category): ?>
                            <option value="<?php echo $category['id']; ?>" <?php echo (isset($product) && $product['category_id'] == $category['id']) ? 'selected' : ''; ?>>
                                <?php echo $category['nama']; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="deskripsi">Deskripsi</label>
                    <textarea id="deskripsi" name="deskripsi" rows="3"><?php echo $product['deskripsi'] ?? ''; ?></textarea>
                </div>
                
                <div class="form-group">
                    <label for="harga_jual">Harga Jual</label>
                    <input type="number" id="harga_jual" name="harga_jual" value="<?php echo $product['harga_jual'] ?? ''; ?>" min="0" step="0.01" required>
                </div>
                
                <div class="form-group">
                    <label for="harga_beli">Harga Beli</label>
                    <input type="number" id="harga_beli" name="harga_beli" value="<?php echo $product['harga_beli'] ?? ''; ?>" min="0" step="0.01">
                </div>
                
                <div class="form-group">
                    <label for="stok">Stok</label>
                    <input type="number" id="stok" name="stok" value="<?php echo $product['stok'] ?? ''; ?>" min="0" required>
                </div>
                
                <div class="form-group">
                    <label for="gambar">Gambar Produk</label>
                    <input type="file" id="gambar" name="gambar" accept="image/jpeg,image/png">
                    <small>Hanya file JPG/PNG, maksimal 2MB</small>
                    
                    <?php if (isset($product) && $product['gambar_path']): ?>
                        <div class="current-image">
                            <p>Gambar saat ini:</p>
                            <img src="<?php echo $product['gambar_path']; ?>" alt="<?php echo $product['nama']; ?>" class="product-image-preview">
                        </div>
                    <?php endif; ?>
                </div>
                
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Simpan
                    </button>
                    <a href="products.php" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Batal
                    </a>
                </div>
            </form>
        </div>
        
        <footer>
            <p>&copy; <?php echo date('Y'); ?> Aplikasi Penjualan Barang</p>
        </footer>
    </div>
</body>
</html>