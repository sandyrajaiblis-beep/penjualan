<?php
require_once 'koneksi.php';

// Hapus session
session_unset();
session_destroy();

// Redirect ke halaman login
header("Location: index.php");
exit;
?>