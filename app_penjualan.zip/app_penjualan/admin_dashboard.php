<?php
require_once 'koneksi.php';

// Cek login
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

// Get today's date
$today = date('Y-m-d');

// Get total sales today
$stmt = $conn->prepare("SELECT COUNT(*) as total_sales, SUM(total_amount) as total_revenue FROM sales WHERE DATE(created_at) = ?");
$stmt->bind_param("s", $today);
$stmt->execute();
$result = $stmt->get_result();
$today_stats = $result->fetch_assoc();

// Get low stock products
$stmt = $conn->prepare("SELECT id, nama, stok FROM products WHERE stok <= 10 ORDER BY stok ASC LIMIT 5");
$stmt->execute();
$result = $stmt->get_result();
$low_stock_products = $result->fetch_all(MYSQLI_ASSOC);

// Get recent sales
$stmt = $conn->prepare("SELECT s.id, s.invoice_no, s.total_amount, s.created_at, c.nama as customer_name 
                        FROM sales s 
                        LEFT JOIN customers c ON s.customer_id = c.id 
                        ORDER BY s.created_at DESC LIMIT 5");
$stmt->execute();
$result = $stmt->get_result();
$recent_sales = $result->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Dashboard Admin</h1>
            <div class="user-info">
                <span>Selamat datang, <?php echo $_SESSION['admin_name']; ?></span>
                <a href="logout.php" class="btn btn-logout">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </header>
        
        <div class="dashboard-stats">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-shopping-cart"></i>
                </div>
                <div class="stat-info">
                    <h3>Transaksi Hari Ini</h3>
                    <p><?php echo $today_stats['total_sales']; ?></p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-money-bill-wave"></i>
                </div>
                <div class="stat-info">
                    <h3>Pendapatan Hari Ini</h3>
                    <p>Rp <?php echo number_format($today_stats['total_revenue'], 0, ',', '.'); ?></p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-exclamation-triangle"></i>
                </div>
                <div class="stat-info">
                    <h3>Stok Menipis</h3>
                    <p><?php echo count($low_stock_products); ?> Produk</p>
                </div>
            </div>
        </div>
        
        <div class="dashboard-sections">
            <div class="section">
                <h2>Produk Stok Menipis</h2>
                <?php if (count($low_stock_products) > 0): ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Nama Produk</th>
                                <th>Stok</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($low_stock_products as $product): ?>
                                <tr>
                                    <td><?php echo $product['nama']; ?></td>
                                    <td><?php echo $product['stok']; ?></td>
                                    <td>
                                        <a href="product_form.php?id=<?php echo $product['id']; ?>" class="btn btn-sm btn-primary">
                                            <i class="fas fa-edit"></i> Edit
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>Tidak ada produk dengan stok menipis.</p>
                <?php endif; ?>
            </div>
            
            <div class="section">
                <h2>Transaksi Terakhir</h2>
                <?php if (count($recent_sales) > 0): ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Invoice</th>
                                <th>Pelanggan</th>
                                <th>Total</th>
                                <th>Tanggal</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent_sales as $sale): ?>
                                <tr>
                                    <td><?php echo $sale['invoice_no']; ?></td>
                                    <td><?php echo $sale['customer_name'] ?: 'Umum'; ?></td>
                                    <td>Rp <?php echo number_format($sale['total_amount'], 0, ',', '.'); ?></td>
                                    <td><?php echo date('d/m/Y H:i', strtotime($sale['created_at'])); ?></td>
                                    <td>
                                        <a href="sales_list.php" class="btn btn-sm btn-info">
                                            <i class="fas fa-eye"></i> Lihat Detail
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>Belum ada transaksi.</p>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="dashboard-menu">
            <a href="products.php" class="btn btn-primary">
                <i class="fas fa-box"></i> Manajemen Produk
            </a>
            <a href="pos.php" class="btn btn-success">
                <i class="fas fa-cash-register"></i> Kasir/POS
            </a>
            <a href="sales_list.php" class="btn btn-info">
                <i class="fas fa-list"></i> Daftar Penjualan
            </a>
        </div>
        
        <footer>
            <p>&copy; <?php echo date('Y'); ?> Aplikasi Penjualan Barang</p>
        </footer>
    </div>
</body>
</html>