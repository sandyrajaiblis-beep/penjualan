<?php
require_once 'koneksi.php';

// Cek login
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

// Ambil path gambar dari parameter
if (isset($_GET['path'])) {
    $image_path = $_GET['path'];
    
    // Validasi path untuk mencegah directory traversal
    $real_path = realpath($image_path);
    $base_path = realpath(__DIR__ . '/assets/uploads/products/');
    
    if ($real_path === false || strpos($real_path, $base_path) !== 0) {
        header("HTTP/1.0 404 Not Found");
        exit;
    }
    
    // Cek apakah file ada
    if (file_exists($real_path)) {
        // Ambil info file
        $image_info = getimagesize($real_path);
        $mime_type = $image_info['mime'];
        
        // Set header
        header('Content-Type: ' . $mime_type);
        header('Content-Length: ' . filesize($real_path));
        header('Cache-Control: public');
        
        // Tampilkan gambar
        readfile($real_path);
        exit;
    }
}

// Jika file tidak ditemukan
header("HTTP/1.0 404 Not Found");
exit;
?>