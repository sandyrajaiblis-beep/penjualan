<?php
require_once 'koneksi.php';

// Cek login
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

// Proses penjualan
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $invoice_no = $_POST['invoice_no'];
    $customer_id = !empty($_POST['customer_id']) ? $_POST['customer_id'] : null;
    $pembayaran_method = $_POST['pembayaran_method'];
    $cart_items = json_decode($_POST['cart_items'], true);
    
    // Validasi keranjang
    if (empty($cart_items)) {
        $_SESSION['error'] = "Keranjang belanja kosong!";
        header("Location: pos.php");
        exit;
    }
    
    // Hitung total
    $total_amount = 0;
    $total_items = 0;
    
    foreach ($cart_items as $item) {
        $subtotal = $item['harga'] * $item['qty'];
        $total_amount += $subtotal;
        $total_items += $item['qty'];
    }
    
    // Mulai transaksi
    $conn->begin_transaction();
    
    try {
        // Simpan data penjualan
        // Simpan data penjualan
if ($customer_id === null) {
    // Gunakan query dengan NULL langsung di SQL
    $stmt = $conn->prepare("INSERT INTO sales (invoice_no, customer_id, total_amount, total_items, pembayaran_method) VALUES (?, NULL, ?, ?, ?)");
    $stmt->bind_param("sdis", $invoice_no, $total_amount, $total_items, $pembayaran_method);
} else {
    $stmt = $conn->prepare("INSERT INTO sales (invoice_no, customer_id, total_amount, total_items, pembayaran_method) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sidis", $invoice_no, $customer_id, $total_amount, $total_items, $pembayaran_method);
}
$stmt->execute();
$sale_id = $conn->insert_id;
        
        // Simpan detail penjualan dan kurangi stok
        foreach ($cart_items as $item) {
            $subtotal = $item['harga'] * $item['qty'];
            
            // Simpan detail penjualan
            $stmt = $conn->prepare("INSERT INTO sale_items (sale_id, product_id, qty, price, subtotal) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("iiidd", $sale_id, $item['id'], $item['qty'], $item['harga'], $subtotal);
            $stmt->execute();
            
            // Kurangi stok produk
            $stmt = $conn->prepare("UPDATE products SET stok = stok - ? WHERE id = ? AND stok >= ?");
            $stmt->bind_param("iii", $item['qty'], $item['id'], $item['qty']);
            $stmt->execute();
            
            // Cek apakah stok berhasil dikurangi
            if ($stmt->affected_rows == 0) {
                throw new Exception("Stok produk " . $item['nama'] . " tidak mencukupi!");
            }
        }
        
        // Commit transaksi
        $conn->commit();
        
        $_SESSION['success'] = "Penjualan berhasil diproses! Nomor invoice: " . $invoice_no;
        header("Location: pos.php");
        exit;
    } catch (Exception $e) {
        // Rollback transaksi
        $conn->rollback();
        
        $_SESSION['error'] = "Terjadi kesalahan: " . $e->getMessage();
        header("Location: pos.php");
        exit;
    }
}

// Redirect jika bukan POST
header("Location: pos.php");
exit;
?>