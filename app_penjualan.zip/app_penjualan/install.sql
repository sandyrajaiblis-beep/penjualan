-- Buat database
CREATE DATABASE IF NOT EXISTS db_penjualan;
USE db_penjualan;

-- Tabel Admin
CREATE TABLE IF NOT EXISTS admins (
    id INT(11) PRIMARY KEY AUTO_INCREMENT,
    nama VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabel Kategori
CREATE TABLE IF NOT EXISTS categories (
    id INT(11) PRIMARY KEY AUTO_INCREMENT,
    nama VARCHAR(100) NOT NULL,
    slug VARCHAR(100) NOT NULL UNIQUE
);

-- Tabel Produk
CREATE TABLE IF NOT EXISTS products (
    id INT(11) PRIMARY KEY AUTO_INCREMENT,
    sku VARCHAR(50) NOT NULL UNIQUE,
    nama VARCHAR(100) NOT NULL,
    category_id INT(11),
    deskripsi TEXT,
    harga_jual DECIMAL(10,2) NOT NULL,
    harga_beli DECIMAL(10,2),
    stok INT(11) NOT NULL DEFAULT 0,
    gambar_path VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id)
);

-- Tabel Pelanggan
CREATE TABLE IF NOT EXISTS customers (
    id INT(11) PRIMARY KEY AUTO_INCREMENT,
    nama VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    telepon VARCHAR(20),
    alamat TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabel Penjualan
CREATE TABLE IF NOT EXISTS sales (
    id INT(11) PRIMARY KEY AUTO_INCREMENT,
    invoice_no VARCHAR(20) NOT NULL UNIQUE,
    customer_id INT(11),
    total_amount DECIMAL(10,2) NOT NULL,
    total_items INT(11) NOT NULL,
    pembayaran_method VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id)
);

-- Tabel Detail Penjualan
CREATE TABLE IF NOT EXISTS sale_items (
    id INT(11) PRIMARY KEY AUTO_INCREMENT,
    sale_id INT(11) NOT NULL,
    product_id INT(11) NOT NULL,
    qty INT(11) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    subtotal DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (sale_id) REFERENCES sales(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Tambahkan indeks
CREATE INDEX idx_sku ON products(sku);
CREATE INDEX idx_email ON customers(email);
CREATE INDEX idx_invoice ON sales(invoice_no);
CREATE INDEX idx_product_category ON products(category_id);

-- Insert data awal
INSERT INTO admins (nama, email, password_hash) VALUES 
('Admin', 'admin@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'); -- password: password

INSERT INTO categories (nama, slug) VALUES 
('Elektronik', 'elektronik'),
('Pakaian', 'pakaian'),
('Makanan', 'makanan'),
('Minuman', 'minuman');

INSERT INTO products (sku, nama, category_id, deskripsi, harga_jual, harga_beli, stok) VALUES 
('ELEC001', 'Smartphone Android', 1, 'Smartphone dengan layar 6 inch', 2500000.00, 2000000.00, 10),
('ELEC002', 'Laptop 14 inch', 1, 'Laptop dengan RAM 8GB', 7500000.00, 6500000.00, 5),
('PAK001', 'Kaos Polos', 2, 'Kaos katun dengan berbagai warna', 75000.00, 50000.00, 50),
('MAK001', 'Keripik Kentang', 3, 'Keripik kentang rasa original', 15000.00, 10000.00, 100),
('MIN001', 'Air Mineral Botol', 4, 'Air mineral 600ml', 5000.00, 3000.00, 200);