<?php
require_once 'koneksi.php';

// Cek login
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

// Hapus produk
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    
    // Get product image path
    $stmt = $conn->prepare("SELECT gambar_path FROM products WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $product = $result->fetch_assoc();
    
    // Delete image file if exists
    if ($product['gambar_path'] && file_exists($product['gambar_path'])) {
        unlink($product['gambar_path']);
    }
    
    // Delete product from database
    $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    
    header("Location: products.php");
    exit;
}

// Ambil data produk
$stmt = $conn->prepare("SELECT p.*, c.nama as category_nama FROM products p LEFT JOIN categories c ON p.category_id = c.id ORDER BY p.nama");
$stmt->execute();
$result = $stmt->get_result();
$products = $result->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Produk</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Manajemen Produk</h1>
            <div class="user-info">
                <span>Selamat datang, <?php echo $_SESSION['admin_name']; ?></span>
                <a href="logout.php" class="btn btn-logout">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </header>
        
        <div class="card">
            <div class="card-header">
                <h2>Daftar Produk</h2>
                <a href="product_form.php" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Tambah Produk
                </a>
            </div>
            
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Gambar</th>
                            <th>SKU</th>
                            <th>Nama Produk</th>
                            <th>Kategori</th>
                            <th>Harga Jual</th>
                            <th>Stok</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($products as $product): ?>
                            <tr>
                                <td>
                                    <?php if ($product['gambar_path']): ?>
                                        <img src="<?php echo $product['gambar_path']; ?>" alt="<?php echo $product['nama']; ?>" class="product-thumbnail">
                                    <?php else: ?>
                                        <img src="https://via.placeholder.com/50" alt="No Image" class="product-thumbnail">
                                    <?php endif; ?>
                                </td>
                                <td><?php echo $product['sku']; ?></td>
                                <td><?php echo $product['nama']; ?></td>
                                <td><?php echo $product['category_nama'] ?: '-'; ?></td>
                                <td>Rp <?php echo number_format($product['harga_jual'], 0, ',', '.'); ?></td>
                                <td><?php echo $product['stok']; ?></td>
                                <td>
                                    <a href="product_form.php?id=<?php echo $product['id']; ?>" class="btn btn-sm btn-primary">
                                        <i class="fas fa-edit"></i> Edit
                                    </a>
                                    <a href="products.php?delete=<?php echo $product['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus produk ini?')">
                                        <i class="fas fa-trash"></i> Hapus
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <div class="back-link">
            <a href="admin_dashboard.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Kembali ke Dashboard
            </a>
        </div>
        
        <footer>
            <p>&copy; <?php echo date('Y'); ?> Aplikasi Penjualan Barang</p>
        </footer>
    </div>
</body>
</html>