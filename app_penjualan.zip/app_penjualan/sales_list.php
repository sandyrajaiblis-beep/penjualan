<?php
require_once 'koneksi.php';

// Cek login
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

// Export ke CSV
if (isset($_GET['export']) && $_GET['export'] == 'csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="penjualan_' . date('Y-m-d') . '.csv"');
    
    $output = fopen('php://output', 'w');
    
    // Header CSV
    fputcsv($output, ['Invoice', 'Tanggal', 'Pelanggan', 'Total', 'Metode Pembayaran']);
    
    // Data penjualan
    $stmt = $conn->prepare("SELECT s.invoice_no, s.created_at, c.nama as customer_nama, s.total_amount, s.pembayaran_method 
                           FROM sales s 
                           LEFT JOIN customers c ON s.customer_id = c.id 
                           ORDER BY s.created_at DESC");
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        fputcsv($output, [
            $row['invoice_no'],
            date('d/m/Y H:i', strtotime($row['created_at'])),
            $row['customer_nama'] ?: 'Umum',
            $row['total_amount'],
            $row['pembayaran_method']
        ]);
    }
    
    fclose($output);
    exit;
}

// Filter tanggal
$date_from = $_GET['date_from'] ?? date('Y-m-01');
$date_to = $_GET['date_to'] ?? date('Y-m-d');

// Ambil data penjualan
$stmt = $conn->prepare("SELECT s.id, s.invoice_no, s.created_at, c.nama as customer_nama, s.total_amount, s.pembayaran_method 
                        FROM sales s 
                        LEFT JOIN customers c ON s.customer_id = c.id 
                        WHERE DATE(s.created_at) BETWEEN ? AND ? 
                        ORDER BY s.created_at DESC");
$stmt->bind_param("ss", $date_from, $date_to);
$stmt->execute();
$result = $stmt->get_result();
$sales = $result->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Penjualan</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Daftar Penjualan</h1>
            <div class="user-info">
                <span>Selamat datang, <?php echo $_SESSION['admin_name']; ?></span>
                <a href="logout.php" class="btn btn-logout">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </header>
        
        <div class="card">
            <div class="card-header">
                <h2>Filter Penjualan</h2>
            </div>
            
            <form method="GET" action="" class="filter-form">
                <div class="form-group">
                    <label for="date_from">Dari Tanggal</label>
                    <input type="date" id="date_from" name="date_from" value="<?php echo $date_from; ?>">
                </div>
                
                <div class="form-group">
                    <label for="date_to">Sampai Tanggal</label>
                    <input type="date" id="date_to" name="date_to" value="<?php echo $date_to; ?>">
                </div>
                
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-filter"></i> Filter
                    </button>
                    <a href="sales_list.php?export=csv" class="btn btn-success">
                        <i class="fas fa-file-csv"></i> Export CSV
                    </a>
                </div>
            </form>
        </div>
        
        <div class="card">
            <div class="card-header">
                <h2>Daftar Penjualan</h2>
            </div>
            
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Invoice</th>
                            <th>Tanggal</th>
                            <th>Pelanggan</th>
                            <th>Total</th>
                            <th>Metode Pembayaran</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($sales) > 0): ?>
                            <?php foreach ($sales as $sale): ?>
                                <tr>
                                    <td><?php echo $sale['invoice_no']; ?></td>
                                    <td><?php echo date('d/m/Y H:i', strtotime($sale['created_at'])); ?></td>
                                    <td><?php echo $sale['customer_nama'] ?: 'Umum'; ?></td>
                                    <td>Rp <?php echo number_format($sale['total_amount'], 0, ',', '.'); ?></td>
                                    <td><?php echo $sale['pembayaran_method']; ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-info view-sale-details" data-id="<?php echo $sale['id']; ?>">
                                            <i class="fas fa-eye"></i> Detail
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center">Tidak ada data penjualan</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <div class="back-link">
            <a href="admin_dashboard.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Kembali ke Dashboard
            </a>
        </div>
        
        <footer>
            <p>&copy; <?php echo date('Y'); ?> Aplikasi Penjualan Barang</p>
        </footer>
    </div>
    
    <!-- Modal Detail Penjualan -->
    <div id="saleDetailModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Detail Penjualan</h3>
                <span class="close-modal">&times;</span>
            </div>
            <div class="modal-body">
                <div id="saleDetailContent"></div>
            </div>
        </div>
    </div>
    
    <script>
        // View sale details
        document.querySelectorAll('.view-sale-details').forEach(button => {
            button.addEventListener('click', function() {
                const saleId = this.getAttribute('data-id');
                
                fetch(`get_sale_details.php?id=${saleId}`)
                    .then(response => response.text())
                    .then(data => {
                        document.getElementById('saleDetailContent').innerHTML = data;
                        document.getElementById('saleDetailModal').style.display = 'block';
                    })
                    .catch(error => console.error('Error:', error));
            });
        });
        
        // Close modal
        document.querySelector('.close-modal').addEventListener('click', function() {
            document.getElementById('saleDetailModal').style.display = 'none';
        });
        
        window.addEventListener('click', function(event) {
            const modal = document.getElementById('saleDetailModal');
            if (event.target == modal) {
                modal.style.display = 'none';
            }
        });
    </script>
</body>
</html>